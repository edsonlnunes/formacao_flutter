import 'package:flutter/material.dart';

const primaryColor = Color(0xFF168AAD);
const secondaryColor = Color(0xFF34A0A4);
