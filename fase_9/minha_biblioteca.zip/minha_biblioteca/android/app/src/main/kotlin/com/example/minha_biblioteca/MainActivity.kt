package com.example.minha_biblioteca

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
